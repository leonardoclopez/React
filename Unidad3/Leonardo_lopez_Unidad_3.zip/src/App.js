import logo from './logo.svg';
import './App.css';
import Componente from './Componente'

function App() {
  return (
    <div className="App">
      <header className='App-header'>
        

        <section >  
           
          <Componente />
                 
        </section>
        
      </header>
    </div>
    
  );
}

export default App;
